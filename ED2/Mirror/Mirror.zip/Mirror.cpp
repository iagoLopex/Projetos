#include <bits/stdc++.h>

using namespace std;

struct node{
	int v;
	node *left, *right;
	node(){
		v=0;
		left=right=0;
	}
};

class btree{

private:
	vector<int>vec;  //vector para guardar o caminho infixo
	queue<node*>q;   //queue para insercao em largura
	node *root;
	int n;
	int altura;
	
public:
	btree(){
		root=0;
		n=0;
		altura=0;
	}
	void insert(int x){
		node *aux = new node;
		aux->v = x;
		n++;
		if(!root){
			root = aux;
			q.push(root);
		}
		else{
			node *atual = q.front();
			if(atual->left){	   //se o left tem valor eu insiro na direita e tiro da fila
				atual->right = aux;
				q.push(aux);
				q.pop();
			}
			else{				   //senao insiro no left e nao tiro o elemento da fila
				atual->left = aux;
				q.push(aux);
			}
		}
	}
	void bfs(){
		queue<node*>qu;
		qu.push(root);
		int k=1;
		int cont=0;
		node *a;
		cout << "tree:\n";
		while(k <= ((2*n)-1)){

			cont++;                                //contador para descer os niveis da arvore 1, 2, 4, 8 ...

			for(int i=0; i<k && !qu.empty(); i++){ //imprimir todos os elementos daquele nivel
				
				a = qu.front();
				qu.pop();
				
				cout << "-" << a->v << "-";

				if(a->left) qu.push(a->left);
				if(a->right) qu.push(a->right);				
			}
			cout <<endl;
			k = (1<<cont);                        
		}
		altura = ceil(log2(n));
		
		cout << "altura : " << altura << endl;
	}
	bool mirror(){
		
		cout << "Caminho infixo da arvore:\n";
		auto infix = [&](auto infix, node** t) -> void{
			
			if(!(*t)) return;
			
			infix(infix, &((*t)->left));
			vec.push_back((*t)->v);
			cout << (*t)->v << " ";
			infix(infix, &((*t)->right));
		};
		infix(infix, &root);
		cout << endl << endl;
		
		//verifico se o caminho infixo é palindromo
		int l=0, r=n-1;
		bool palindrome = true;
			
		while(l<r){
			if(vec[l]!=vec[r]){
				palindrome = false;
				break;
			}
			l++;
			r--;
		}
		
		if(palindrome && (1<<altura)-1 != n && n!=1)
			palindrome = false;
			
		vec.clear();
		
		return palindrome;
	}
};

int main(){
	
	btree tree;
	
	tree.insert(1);
	tree.insert(2);
	tree.insert(3);
	tree.insert(3);
	tree.insert(3);
	
	//~ int o, k;
	//~ cin>>o;
	//~ for(int i=0; i<o; i++){
		//~ cin>>k;
		//~ tree.insert(k);
	//~ }
	
	tree.bfs();
	
	cout << (tree.mirror() ? "is mirror" : "isn't mirror") << endl;
}
